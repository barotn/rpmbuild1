echo "hello `whoami`";
